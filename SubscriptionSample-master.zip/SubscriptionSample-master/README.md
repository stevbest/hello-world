# Subscription Sample
Shows a sample subscription management system.  


This is a **VERY** basic subscription sample.  All you have to do is make EndSubscription do the work to end the subscription.  

## Things to Note
- Look at the build dependencies for Subscriptions project in the solution
- Notice the build location of EndSubscription
- To make sub main work in EndSubscription, I turned off the Enable application framework option
